package com.mikepenz.lollipopshowcase.itemanimator;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import java.util.ArrayList;
import java.util.List;


public class CustomItemAnimator extends RecyclerView.ItemAnimator {

    List<RecyclerView.ViewHolder> mPendingAdd = new ArrayList<>();
    List<RecyclerView.ViewHolder> mPendingRemove = new ArrayList<>();

    @Override
    public void runPendingAnimations() {
        int animationDuration = 300;
        if (!mPendingAdd.isEmpty()) {
            for (final RecyclerView.ViewHolder viewHolder : mPendingAdd) {
                View target = viewHolder.itemView;
                target.setPivotX(target.getMeasuredWidth() / 2);
                target.setPivotY(target.getMeasuredHeight() / 2);

                AnimatorSet animator = new AnimatorSet();

                animator.playTogether(
                        ObjectAnimator.ofFloat(target, "translationX", - target.getMeasuredWidth(),
                                0.0f),
                        ObjectAnimator.ofFloat(target, "alpha", target.getAlpha(), 1.0f)
                );

                animator.setTarget(target);
                animator.setDuration(animationDuration);
                animator.setInterpolator(new AccelerateDecelerateInterpolator());
                animator.setStartDelay((animationDuration * viewHolder.getPosition()) / 10);
                animator.addListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animator animation) {
                        mPendingAdd.remove(viewHolder);
                    }

                    @Override
                    public void onAnimationCancel(Animator animation) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animation) {

                    }
                });
                animator.start();
            }
        }
        if (!mPendingRemove.isEmpty()) {
            for (final RecyclerView.ViewHolder viewHolder : mPendingRemove) {
                View target = viewHolder.itemView;
                target.setPivotX(target.getMeasuredWidth() / 2);
                target.setPivotY(target.getMeasuredHeight() / 2);

                AnimatorSet animator = new AnimatorSet();

                animator.playTogether(
                        ObjectAnimator.ofFloat(target, "translationX", 0.0f,
                                target.getMeasuredWidth()),
                        ObjectAnimator.ofFloat(target, "alpha", target.getAlpha(), 0.0f)
                );

                animator.setTarget(target);
                animator.setDuration(animationDuration);
                animator.setInterpolator(new AccelerateDecelerateInterpolator());
                animator.setStartDelay((animationDuration * viewHolder.getPosition()) / 10);
                animator.start();
            }
        }
    }

    @Override
    public boolean animateDisappearance(RecyclerView.ViewHolder viewHolder,
                                        RecyclerView.ItemAnimator.ItemHolderInfo preLayoutInfo,
                                        RecyclerView.ItemAnimator.ItemHolderInfo postLayoutInfo) {
        mPendingRemove.add(viewHolder);
        return false;
    }

    @Override
    public boolean animateAppearance(RecyclerView.ViewHolder viewHolder,
                                     ItemHolderInfo preLayoutInfo, ItemHolderInfo postLayoutInfo) {
        viewHolder.itemView.setAlpha(0.0f);
        return mPendingAdd.add(viewHolder);
    }

    @Override
    public boolean animatePersistence(RecyclerView.ViewHolder viewHolder,
                                      ItemHolderInfo preLayoutInfo, ItemHolderInfo postLayoutInfo) {
        return false;
    }

    @Override
    public boolean animateChange(RecyclerView.ViewHolder oldHolder,
                                 RecyclerView.ViewHolder newHolder,
                                 RecyclerView.ItemAnimator.ItemHolderInfo preLayoutInfo,
                                 RecyclerView.ItemAnimator.ItemHolderInfo postLayoutInfo) {
        return false;
    }

    @Override
    public void endAnimation(RecyclerView.ViewHolder viewHolder) {
    }

    @Override
    public void endAnimations() {
    }

    @Override
    public boolean isRunning() {
        return !mPendingAdd.isEmpty() || !mPendingRemove.isEmpty();
    }

}