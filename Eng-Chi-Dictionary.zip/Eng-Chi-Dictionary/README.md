Eng-Chi-Dictionary
==================
[![Build Status](https://travis-ci.org/ming030890/Eng-Chi-Dictionary.svg?branch=master)](https://travis-ci.org/ming030890/Eng-Chi-Dictionary)</br>

Englist to Chinese dictionary Android app. </br>
This project is released under GNU GPL v2

You could find the review about this app [here](http://www.jianshu.com/p/cd414246bf5e)!
